$('.login-input').on('focus', function() {
  $('.login').addClass('focused');
});

